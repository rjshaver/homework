			
	      	var istable = true;
	      	function clptable(){
	      		
	      		if (istable){
	      			$("#ptable").attr('src', "compsci.jfif"); 
	      		}else {
	      			$("#ptable").attr('src', "images.jfif"); 
	      		}
	      		istable = !istable;

	      	};

	      